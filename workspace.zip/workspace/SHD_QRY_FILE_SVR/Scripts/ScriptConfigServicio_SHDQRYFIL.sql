/*
       Script de configuracion Consulta Liquidaciones por Archivo, convenio Secretaria de Hacienda Distrital (SHDQRYFIL)
       Autor:   Carlos Cuello
       Fecha:   2017-07-21
*/

BEGIN
--Creacion del sistema
  --INSERT INTO PARAMPRO.PAR_SISTEMA VALUES(PARAMPRO.PAR_SISTEMA_SEQ.NEXTVAL,'SHD','Sistema externo recaudo Secretaria de Hacienda Distrital','Luis Fernando Martinez','espinnel',sysdate,NULL,NULL);
--Creacion del servicio
  INSERT INTO PARAMPRO.PAR_SERVICIO VALUES('SHDQRYFIL','Servicio Consulta Liquidaciones por Archivo SHD',44,0,1,1,'Activo','Luis Fernando Martinez','Luis Fernando Martinez',NULL,NULL,'espinnel',sysdate,NULL,NULL,1,1);
   
--Creacion de par�metros
  INSERT INTO PARAMPRO.PAR_PARAMETROS VALUES(PARAMPRO.PAR_PARAMETROS_SEQ.NEXTVAL,'SHDQRYFIL',1,1,'Logging','1','LOG FLAG','U',1,NULL,NULL,NULL,'espinnel',sysdate,NULL,NULL);
  INSERT INTO PARAMPRO.PAR_PARAMETROS VALUES(PARAMPRO.PAR_PARAMETROS_SEQ.NEXTVAL,'SHDQRYFIL',1,1,'Auditoria','1','AUDIT FLAG','U',1,NULL,NULL,NULL,'espinnel',sysdate,NULL,NULL);
  INSERT INTO PARAMPRO.PAR_PARAMETROS VALUES(PARAMPRO.PAR_PARAMETROS_SEQ.NEXTVAL,'SHDQRYFIL',1,1,'FullAuditoria','1','FULLAUDIT FLAG','U',1,NULL,NULL,NULL,'espinnel',sysdate,NULL,NULL);
  INSERT INTO PARAMPRO.PAR_PARAMETROS VALUES(PARAMPRO.PAR_PARAMETROS_SEQ.NEXTVAL,'SHDQRYFIL',1,1,'SDP_SERVICEURL','https://DataPowerBanco:8010/SecretariaHacienda','Url','U',1,NULL,NULL,NULL,'espinnel',sysdate,NULL,NULL);
  INSERT INTO PARAMPRO.PAR_PARAMETROS VALUES(PARAMPRO.PAR_PARAMETROS_SEQ.NEXTVAL,'SHDQRYFIL',1,1,'BankCode_SHDQRYFIL','19','Parametro BankCode_SHDQRYFIL','U',1,NULL,NULL,NULL,'espinnel',sysdate,NULL,NULL);
  
  COMMIT;
END;
